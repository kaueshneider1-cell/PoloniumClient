# Polonium Client 1.0.0 — projeto inicial

Projeto-base de um mod client-side para Minecraft Java 1.8.9 / Forge 11.15.1.2318.

## O que já está implementado no código
- Mod Forge com ID `polonium`.
- Menu próprio aberto com **Right Shift**.
- Categorias HUD, PvP e Visual.
- Botões para ligar/desligar módulos.
- HUD inicial de FPS e coordenadas.

## Ainda não implementado
- Persistência das configurações após fechar o jogo.
- Funcionalidade real para Keystrokes, CPS, Toggle Sprint, Custom Crosshair e Hit Color.
- Integração para ligar/desligar outros mods Forge já carregados.
- Editor de HUD arrastável.
- Testes dentro do Minecraft.

Os módulos sem implementação aparecem como protótipos na interface; não devem ser considerados funcionais ainda.

## Como compilar
Requisitos: JDK 8 e Gradle compatível com ForgeGradle 2.1.

Em um ambiente com JDK 8 e Gradle configurado:
1. Abra a pasta como projeto Gradle.
2. Execute `gradle setupDecompWorkspace`.
3. Execute `gradle build`.
4. O arquivo compilado será criado em `build/libs/PoloniumClient-1.0.0.jar`.

A primeira compilação precisa baixar ForgeGradle e as dependências do Minecraft/Forge.
