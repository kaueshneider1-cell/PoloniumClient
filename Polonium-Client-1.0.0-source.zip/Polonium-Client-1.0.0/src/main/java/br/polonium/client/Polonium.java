package br.polonium.client;

import br.polonium.client.gui.PoloniumGui;
import br.polonium.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = Polonium.MODID, name = Polonium.NAME, version = Polonium.VERSION, clientSideOnly = true)
public class Polonium {
    public static final String MODID = "polonium";
    public static final String NAME = "Polonium Client";
    public static final String VERSION = "1.0.0";

    private static KeyBinding openMenuKey;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ModuleManager.init();
        openMenuKey = new KeyBinding("key.polonium.menu", Keyboard.KEY_RSHIFT, "key.categories.polonium");
        ClientRegistry.registerKeyBinding(openMenuKey);
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new br.polonium.client.module.HudRenderer());
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (openMenuKey != null && openMenuKey.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new PoloniumGui());
        }
    }
}
