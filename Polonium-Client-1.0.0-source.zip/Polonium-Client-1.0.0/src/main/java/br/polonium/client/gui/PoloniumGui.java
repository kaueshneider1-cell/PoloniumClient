package br.polonium.client.gui;

import br.polonium.client.module.ModuleManager;
import br.polonium.client.module.PoloniumModule;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PoloniumGui extends GuiScreen {
    private String category = "HUD";
    private final List<PoloniumModule> visibleModules = new ArrayList<PoloniumModule>();

    @Override
    public void initGui() {
        rebuildButtons();
    }

    private void rebuildButtons() {
        this.buttonList.clear();
        this.buttonList.add(new GuiButton(1, this.width / 2 - 150, this.height / 2 + 105, 300, 20, "Fechar"));
        this.buttonList.add(new GuiButton(10, this.width / 2 - 150, this.height / 2 - 105, 96, 20, "HUD"));
        this.buttonList.add(new GuiButton(11, this.width / 2 - 48, this.height / 2 - 105, 96, 20, "PvP"));
        this.buttonList.add(new GuiButton(12, this.width / 2 + 54, this.height / 2 - 105, 96, 20, "Visual"));

        visibleModules.clear();
        int row = 0;
        for (PoloniumModule module : ModuleManager.getModules()) {
            if (!module.getCategory().equals(category)) continue;
            visibleModules.add(module);
            String state = module.isEnabled() ? "ON" : "OFF";
            this.buttonList.add(new GuiButton(100 + row, this.width / 2 - 110,
                    this.height / 2 - 65 + row * 25, 220, 20,
                    module.getName() + "  [" + state + "]"));
            row++;
        }
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id == 1) {
            this.mc.displayGuiScreen(null);
            return;
        }
        if (button.id == 10) category = "HUD";
        else if (button.id == 11) category = "PvP";
        else if (button.id == 12) category = "Visual";
        else if (button.id >= 100) {
            int index = button.id - 100;
            if (index >= 0 && index < visibleModules.size()) visibleModules.get(index).toggle();
        }
        rebuildButtons();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        drawRect(this.width / 2 - 165, this.height / 2 - 125,
                this.width / 2 + 165, this.height / 2 + 135, 0xE91B1B27);
        drawRect(this.width / 2 - 165, this.height / 2 - 125,
                this.width / 2 + 165, this.height / 2 - 122, 0xFFFF4FA3);
        drawCenteredString(this.fontRendererObj, "POLONIUM CLIENT", this.width / 2,
                this.height / 2 - 145, 0xFFFF70B5);
        drawCenteredString(this.fontRendererObj, "Categoria: " + category, this.width / 2,
                this.height / 2 - 82, 0xFFFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) {
            this.mc.displayGuiScreen(null);
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
