package br.polonium.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<PoloniumModule> MODULES = new ArrayList<PoloniumModule>();

    private ModuleManager() {}

    public static void init() {
        if (!MODULES.isEmpty()) return;
        MODULES.add(new PoloniumModule("FPS", "HUD", true));
        MODULES.add(new PoloniumModule("Coordinates", "HUD", true));
        MODULES.add(new PoloniumModule("Keystrokes", "HUD", false));
        MODULES.add(new PoloniumModule("CPS", "HUD", false));
        MODULES.add(new PoloniumModule("Toggle Sprint", "PvP", false));
        MODULES.add(new PoloniumModule("Custom Crosshair", "Visual", false));
        MODULES.add(new PoloniumModule("Hit Color", "Visual", false));
    }

    public static List<PoloniumModule> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static PoloniumModule get(String name) {
        for (PoloniumModule module : MODULES) {
            if (module.getName().equalsIgnoreCase(name)) return module;
        }
        return null;
    }

    public static boolean isEnabled(String name) {
        PoloniumModule module = get(name);
        return module != null && module.isEnabled();
    }
}
