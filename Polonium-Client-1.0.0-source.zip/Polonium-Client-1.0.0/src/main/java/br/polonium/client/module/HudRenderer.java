package br.polonium.client.module;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HudRenderer {
    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;

        int y = 6;
        if (ModuleManager.isEnabled("FPS")) {
            mc.fontRendererObj.drawStringWithShadow("Polonium | " + Minecraft.getDebugFPS() + " FPS", 6, y, 0xFFFFFF);
            y += 10;
        }
        if (ModuleManager.isEnabled("Coordinates")) {
            String coords = String.format("X: %.1f  Y: %.1f  Z: %.1f",
                    mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
            mc.fontRendererObj.drawStringWithShadow(coords, 6, y, 0xFFFFFF);
        }
    }
}
